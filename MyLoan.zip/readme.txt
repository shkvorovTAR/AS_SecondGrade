1. Create functions getDouble, getInt
2. Add static to method getInstance of Loan class, because it is Singleton class
3. Add function setInterestRate for set rate value.
4. Add function setPeriods to the Loan class
5. Add function getPeriods to the Loan class
6. In class PlanActivity set type of ArrayList - String. And set type of ArrayAdapter - String
7. In class PlanActivity set R.string resourses
8. In class PlanActivity for (int n = 1; n <= Loan.getInstance().getPeriods(); ++n)
   Because it's "n" local variable 
9. In class PlanActivity set adapter initialization
10. In layout activity_plan.xml set 4 columns instead of 44 

