package hnagel413.com.myloan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private EditText txtCost, txtLoan, txtRate, txtPaym, txtYear, txtTerm;
    private Button btnAmortisation, btnCalculate, btnClear;
    private TextView lblPayment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAmortisation = findViewById(R.id.btnAmortisation);

        txtCost = (EditText) findViewById(R.id.txtCost);
        txtLoan = (EditText) findViewById(R.id.txtLoan);
        txtRate = (EditText) findViewById(R.id.txtRate);
        txtPaym = (EditText) findViewById(R.id.txtPaym);
        txtYear = (EditText) findViewById(R.id.txtYear);
        txtTerm = (EditText) findViewById(R.id.txtTerm);
        btnAmortisation = (Button) findViewById(R.id.btnAmortisation);
        btnCalculate = (Button) findViewById(R.id.btnCalculate);
        btnClear = (Button) findViewById(R.id.btnClear);
        lblPayment = (TextView) findViewById(R.id.lblPayment);


        setPaymentStatus(View.INVISIBLE);
    }


    public void setPaymentStatus(int status) {
       txtPaym.setVisibility(status);
       btnAmortisation.setVisibility(status);
        lblPayment.setVisibility(status);

    }
    public void message(String message) {
        Toast toast = Toast.makeText(getApplicationContext(),
                message,
                Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.BOTTOM, 0, 0);
        toast.show();
    }
    //issue 1
    public double getDouble(EditText element,double def,String message){
        Boolean ret = true;
        try {
            String text = element.getText().toString().trim();
            if (text.length() > 0) {
                double value = Double.parseDouble(text);
                if (value < 0) {
                    ret=false;
                }
                else return value;
            }
        } catch (Exception ex) {
            ret=false;

        }
        if (!ret){
            Toast toast = Toast.makeText(getApplicationContext(),
                    message,
                    Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM, 0, 0);
            toast.show();
            return def;
        }
        return 0;
    }
    public int getInt(EditText element,int def,String message){
        Boolean ret = true;
        try {
            String text = element.getText().toString().trim();
            if (text.length() > 0) {
                int value = Integer.parseInt(text);
                if (value < 0) {
                    ret=false;
                }
                else return value;
            }
        } catch (Exception ex) {
            ret=false;

        }
        if (!ret){
            Toast toast = Toast.makeText(getApplicationContext(),
                    message,
                    Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM, 0, 0);
            toast.show();
            return def;
        }
        return 0;
    }

    public void clear(View v){
        txtCost.setText("");
        txtLoan.setText("");
        txtRate.setText("");
        txtPaym.setText("");
        txtYear.setText("");
        txtTerm.setText("");
        //issue 2
        Loan.getInstance().setPrincipal(1);
        Loan.getInstance().setInterestRate(1);
        Loan.getInstance().setPeriods(1);
        txtCost.requestFocus();
        setPaymentStatus(View.INVISIBLE);
    }

    public void calc(View v){
        Boolean ret = true;

        double cost = getDouble(txtCost,0,"Please entry cost value");
        if (cost<0){
            ret=false;
            message("Cost value must not be negative!");
        }
        double loan = getDouble(txtLoan,0,"Please entry loan value");
        if (ret && loan<=0){
            ret=false;
            message("Loan value must be positive!");
        }

        double rate = getDouble(txtRate,0,"Please entry rate value");
        if (ret && rate<=0){
            ret=false;
            message("Rate value must be positive!");
        }
        if (ret && rate>=50){
            ret=false;
            message("The interest rate must be positive and less than 50!");
        }

        int year = getInt(txtYear,0,"Please entry year value");
        if (ret && (year<1 || year>60) ){
            ret=false;
            message("Years must be an integer between 1 and 60 (both inclusive)!");
        }

        int term = getInt(txtTerm,0,"Please entry term value");
        if (ret && (term<1 || term>12) ){
            ret=false;
            message("The number of terms per years must be an integer between 1 and 12 (both inclusive)!");
        }

        if (ret) {
            Loan.getInstance().setPrincipal(loan + cost);
            Loan.getInstance().setInterestRate(rate / 100 / term);
            Loan.getInstance().setPeriods(year * term);
            txtPaym.setText(String.format("%1.2f", Loan.getInstance().payment()));
            setPaymentStatus(View.VISIBLE);
            btnAmortisation.requestFocus();

        } else {setPaymentStatus(View.INVISIBLE);}
    }



    public void onAmort(View view) {
        if (Loan.getInstance().getPeriods() > 0) {
            Intent intent = new Intent(this, PlanActivity.class);
            startActivity(intent);
        }
    }
}
