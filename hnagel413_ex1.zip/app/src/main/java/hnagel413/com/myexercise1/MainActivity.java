package hnagel413.com.myexercise1;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    final String LOG_TAG = "hnagel413";

    boolean bound = false;
    ServiceConnection sConn;
    MyClock myClock;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        intent = new Intent(this, MyClock.class);

        sConn = new ServiceConnection() {
            public void onServiceConnected(ComponentName name, IBinder binder) {
                ((TextView)findViewById(R.id.labelMain)).setText("Connected");
                myClock = ((MyClock.MyClockBinder) binder).getService();
                bound = true;
            }

            public void onServiceDisconnected(ComponentName name) {
                ((TextView)findViewById(R.id.labelMain)).setText("Disconnected");
                bound = false;
            }
        };

    }

    public void onClickStart(View v) {
        startService(intent);
        bindService(intent, sConn, BIND_AUTO_CREATE);
    }

    public void onClickDate(View v) {
        if (bound){
            ((TextView)findViewById(R.id.labelMain)).setText(myClock.getDate());
        }
    }

    public void onClickTime(View v) {
        if (bound){
            ((TextView)findViewById(R.id.labelMain)).setText(myClock.getTime());
        }
    }
}
