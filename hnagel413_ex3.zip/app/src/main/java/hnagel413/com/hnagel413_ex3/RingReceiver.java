package hnagel413.com.hnagel413_ex3;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.List;

public class RingReceiver extends BroadcastReceiver {
    Context context;

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent intentService = new Intent(context, RingService.class);
        context.startService(intentService);
    }



}
