package hnagel413.com.myloan;

import android.app.ActionBar;
import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.List;

public class PlanActivity extends Activity {
    //issue 6
    private List<String> items = new ArrayList();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);
        //issue 7
        items.add(getResources().getString(R.string.period));
        items.add(getResources().getString(R.string.intr));
        items.add(getResources().getString(R.string.rep));
        items.add(getResources().getString(R.string.outs));
        //issue 8
        for (int n = 1; n <= Loan.getInstance().getPeriods(); ++n)
        {
            items.add("" + n);
            items.add(String.format("%1.2f", Loan.getInstance().interest(n)));
            items.add(String.format("%1.2f", Loan.getInstance().repayment(n)));
            items.add(String.format("%1.2f", Math.abs(Loan.getInstance().outstanding(n))));
        }
        //issue 9
        adapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
        GridView grid = findViewById(R.id.grid);
        grid.setAdapter(adapter);
    }


}
