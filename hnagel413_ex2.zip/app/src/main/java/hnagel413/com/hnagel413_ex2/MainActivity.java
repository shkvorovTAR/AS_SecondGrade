package hnagel413.com.hnagel413_ex2;

import android.content.Intent;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onChangeColor(View v) {
        ((LinearLayout)findViewById(R.id.mainLayout)).setBackgroundColor(Color.BLUE);
    }

    public void onSendMessage(View v) {
        startService(new Intent(this, HangelRemoteService.class));
    }

}
