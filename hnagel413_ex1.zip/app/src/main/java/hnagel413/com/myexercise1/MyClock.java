package hnagel413.com.myexercise1;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MyClock extends IntentService {
    final String LOG_TAG = "hnagel413";
    private static final String serviceName = "MyClock";
    MyClockBinder binder = new MyClockBinder();

    public MyClock() {
        super(serviceName);
        Log.d(LOG_TAG,"MyClock");
    }

    public IBinder onBind(Intent intent) {
        return binder;
    }

    public void onRebind(Intent intent) {
        super.onRebind(intent);
        Log.d(LOG_TAG, "MyService onRebind");
    }

    public boolean onUnbind(Intent intent) {
        Log.d(LOG_TAG, "MyService onUnbind");
        return super.onUnbind(intent);
    }

    String getDate() {
        Date currentTime = Calendar.getInstance().getTime();
        DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(getApplicationContext());
        return dateFormat.format(currentTime);
    }

    String getTime() {
        Date currentTime = Calendar.getInstance().getTime();
        DateFormat dateFormat = android.text.format.DateFormat.getTimeFormat(getApplicationContext());
        return dateFormat.format(currentTime);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        if (intent != null) {
            final String action = intent.getAction();

        }
    }

    class MyClockBinder extends Binder {
        MyClock getService() {
            return MyClock.this;
        }
    }
}
