package hnagel413.com.hnagel413_ex2;

import android.app.IntentService;
import android.content.Intent;
import android.content.Context;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

public class HangelRemoteService extends IntentService {
    final String LOG_TAG = "hnagel";

    public HangelRemoteService() {
        super("HangelRemoteService");
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(LOG_TAG, "onStartCommand");
        SystemClock.sleep(5000);
        Toast toast = Toast.makeText(getApplicationContext(),
                "Test message!",
                Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

    }



}
